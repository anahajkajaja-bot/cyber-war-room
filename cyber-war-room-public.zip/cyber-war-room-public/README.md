# CYBER WAR ROOM — Public Website + Private Admin

Website publik dapat diakses semua orang. Panel `/admin.html` dan semua endpoint kontrol memerlukan login admin.

## Kredensial admin awal
Username: `jaccksallas-admin`

Password: gunakan password unik yang diberikan bersama paket ini di pesan ChatGPT. Masukkan ke environment `ADMIN_PASSWORD` pada Render. Jangan commit password ke GitHub.

## Deploy ke Render
1. Buat repository GitHub baru dan upload seluruh isi folder ini (jangan upload `.env` berisi rahasia).
2. Buka https://render.com/ lalu pilih **New > Blueprint** dan hubungkan repository, atau buat **New > Web Service**.
3. Untuk Web Service isi:
   - Runtime: Node
   - Build command: `npm install`
   - Start command: `npm start`
   - Plan: Free (untuk uji coba)
4. Tambahkan environment:
   - `ADMIN_USERNAME` = `jaccksallas-admin`
   - `ADMIN_PASSWORD` = password admin dari pesan ChatGPT (ubah ke password unik sebelum deploy)
   - `SESSION_SECRET` = random secret minimal 32 karakter (Blueprint dapat meng-generate otomatis)
   - `TARGET_ALLOWLIST` = `localhost,127.0.0.1` (tambahkan hanya hostname yang kamu miliki/diizinkan)
5. Deploy. Situs publik akan tersedia di domain `*.onrender.com`. Panel admin ada di `/admin.html`.

## Fitur & batasan
- Website utama publik; panel admin private dengan sesi HttpOnly, Secure, SameSite=Strict, masa sesi 8 jam.
- Login dilindungi pembatasan percobaan (5 gagal -> jeda 15 menit per IP).
- Endpoint diagnostik hanya dapat dipakai admin yang login.
- GET saja, host harus exact match allowlist, port dibatasi, maks 2 request/detik selama maks 30 detik.
- Tidak ada flood, spoofing, exploit, atau bypass.
- Free Render spin-down setelah 15 menit tanpa trafik dan filesystem bersifat sementara. Ini sesuai batasan layanan gratis Render; lihat dokumentasi resmi.
