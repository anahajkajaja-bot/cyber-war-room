const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const { URL } = require("node:url");

const PORT = Number(process.env.PORT || 10000);
const HOST = "0.0.0.0";
const ADMIN_USER = process.env.ADMIN_USERNAME;
const ADMIN_PASS = process.env.ADMIN_PASSWORD;
const SESSION_SECRET = process.env.SESSION_SECRET;
const allowlist = new Set((process.env.TARGET_ALLOWLIST || "localhost,127.0.0.1")
  .split(",").map(x => x.trim().toLowerCase()).filter(Boolean));
const PUBLIC = path.join(__dirname, "public");
const sessions = new Map();
const loginAttempts = new Map();
let active = false, lastRun = null;
const logs = [];

if (!ADMIN_USER || !ADMIN_PASS || !SESSION_SECRET || ADMIN_PASS.length < 16 || SESSION_SECRET.length < 32) {
  console.error("FATAL: Set ADMIN_USERNAME, ADMIN_PASSWORD (min 16 chars), and SESSION_SECRET (min 32 chars).");
  process.exit(1);
}
function log(level, message) {
  logs.unshift({ time: new Date().toISOString(), level, message });
  if (logs.length > 100) logs.pop();
}
function json(res, code, data, headers = {}) {
  res.writeHead(code, { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", ...headers });
  res.end(JSON.stringify(data));
}
function parseCookies(req) {
  return Object.fromEntries((req.headers.cookie || "").split(";").map(v => v.trim()).filter(Boolean)
    .map(v => { const i = v.indexOf("="); return [v.slice(0,i), decodeURIComponent(v.slice(i+1))]; }));
}
function sign(value) {
  return crypto.createHmac("sha256", SESSION_SECRET).update(value).digest("base64url");
}
function makeSession(res) {
  const id = crypto.randomBytes(32).toString("base64url");
  const expires = Date.now() + 8 * 60 * 60 * 1000;
  sessions.set(id, expires);
  const value = `${id}.${expires}`;
  res.setHeader("Set-Cookie", `cw_session=${encodeURIComponent(value + "." + sign(value))}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=28800`);
}
function isAdmin(req) {
  const token = parseCookies(req).cw_session;
  if (!token) return false;
  const parts = token.split(".");
  if (parts.length !== 3) return false;
  const [id, exp, sig] = parts;
  const value = `${id}.${exp}`;
  const expected = sign(value);
  const a = Buffer.from(sig), b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a,b)) return false;
  const expiry = Number(exp);
  if (!Number.isFinite(expiry) || expiry < Date.now() || sessions.get(id) !== expiry) return false;
  return true;
}
function clearSession(req, res) {
  const token = parseCookies(req).cw_session;
  if (token) sessions.delete(token.split(".")[0]);
  res.setHeader("Set-Cookie", "cw_session=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0");
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", c => { body += c; if (body.length > 8192) { reject(new Error("Request too large")); req.destroy(); } });
    req.on("end", () => { try { resolve(JSON.parse(body || "{}")); } catch { reject(new Error("Invalid JSON")); } });
  });
}
function sameOrigin(req) {
  const origin = req.headers.origin;
  if (!origin) return true;
  try { return new URL(origin).host === req.headers.host; } catch { return false; }
}
function safeTarget(raw) {
  let u; try { u = new URL(raw); } catch { throw new Error("URL HTTP/HTTPS tidak valid."); }
  if (!["http:", "https:"].includes(u.protocol) || u.username || u.password) throw new Error("URL tidak diizinkan.");
  if (!allowlist.has(u.hostname.toLowerCase())) throw new Error("Host tidak ada di TARGET_ALLOWLIST server.");
  if (u.port && !["80","443","8080","8443"].includes(u.port)) throw new Error("Port tidak diizinkan.");
  return u;
}
async function runDiagnostic(target, durationSec, intervalMs) {
  active = true; const started = Date.now(), endAt = started + durationSec * 1000;
  let sent = 0, ok = 0, failed = 0, totalMs = 0;
  log("info", `Diagnostic dimulai: ${target.origin}${target.pathname}`);
  try {
    while (Date.now() < endAt) {
      const t0 = Date.now(), controller = new AbortController(), timeout = setTimeout(() => controller.abort(), 5000);
      try {
        const response = await fetch(target, { method:"GET", redirect:"manual", signal:controller.signal,
          headers:{"user-agent":"CyberWarRoom-Authorized-Diagnostic/1.0"} });
        sent++; totalMs += Date.now()-t0;
        if (response.status >= 200 && response.status < 400) ok++; else failed++;
        await response.arrayBuffer();
      } catch { sent++; failed++; }
      finally { clearTimeout(timeout); }
      const wait = Math.max(0, intervalMs-(Date.now()-t0));
      if (wait && Date.now()+wait < endAt) await new Promise(r=>setTimeout(r,wait));
    }
  } finally {
    active = false;
    lastRun = {target:target.origin+target.pathname,sent,ok,failed,avgLatencyMs:sent?Math.round(totalMs/sent):0,
      durationSec:Math.round((Date.now()-started)/1000),finishedAt:new Date().toISOString()};
    log("success",`Diagnostic selesai: ${sent} request, ${ok} sukses, ${failed} gagal`);
  }
}
const server = http.createServer(async (req,res) => {
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  if (req.method === "GET" && url.pathname === "/api/health") return json(res,200,{ok:true});
  if (req.method === "POST" && url.pathname === "/api/login") {
    if (!sameOrigin(req)) return json(res,403,{error:"Origin ditolak."});
    const ip = req.socket.remoteAddress || "unknown";
    const entry = loginAttempts.get(ip) || {count:0,until:0};
    if (Date.now() < entry.until) return json(res,429,{error:"Terlalu banyak percobaan. Coba lagi nanti."});
    try {
      const body = await readBody(req);
      const userOk = typeof body.username === "string" && body.username.length <= 100 &&
        crypto.timingSafeEqual(Buffer.from(body.username.padEnd(100,"\0").slice(0,100)), Buffer.from(ADMIN_USER.padEnd(100,"\0").slice(0,100)));
      const passOk = typeof body.password === "string" && body.password.length <= 200 &&
        crypto.timingSafeEqual(Buffer.from(body.password.padEnd(200,"\0").slice(0,200)), Buffer.from(ADMIN_PASS.padEnd(200,"\0").slice(0,200)));
      if (!userOk || !passOk) {
        entry.count++; if (entry.count >= 5) { entry.count=0; entry.until=Date.now()+15*60*1000; }
        loginAttempts.set(ip,entry); log("warn","Login admin gagal");
        return json(res,401,{error:"Username atau password salah."});
      }
      loginAttempts.delete(ip); makeSession(res); log("success","Admin login berhasil");
      return json(res,200,{ok:true});
    } catch(e) { return json(res,400,{error:e.message}); }
  }
  if (req.method === "POST" && url.pathname === "/api/logout") {
    if (!sameOrigin(req)) return json(res,403,{error:"Origin ditolak."});
    clearSession(req,res); return json(res,200,{ok:true});
  }
  if (url.pathname.startsWith("/api/admin/") && !isAdmin(req)) return json(res,401,{error:"Admin login diperlukan."});
  if (req.method === "GET" && url.pathname === "/api/admin/status") {
    return json(res,200,{active,lastRun,allowlist:[...allowlist],logs:logs.slice(0,30)});
  }
  if (req.method === "POST" && url.pathname === "/api/admin/diagnostic") {
    if (!sameOrigin(req)) return json(res,403,{error:"Origin ditolak."});
    if (active) return json(res,409,{error:"Diagnostic sedang berjalan."});
    try {
      const body = await readBody(req), target = safeTarget(body.target);
      const duration = Math.max(1,Math.min(30,Number(body.durationSec||10)));
      const rate = Math.max(.2,Math.min(2,Number(body.requestsPerSecond||1)));
      if (!Number.isFinite(duration)||!Number.isFinite(rate)) throw new Error("Parameter tidak valid.");
      runDiagnostic(target,duration,Math.round(1000/rate)).catch(e=>log("error",e.message));
      return json(res,202,{accepted:true,message:"Diagnostic dimulai."});
    } catch(e) { return json(res,400,{error:e.message}); }
  }
  if (req.method === "GET") {
    const requested = url.pathname === "/" ? "/index.html" : url.pathname;
    const file = path.resolve(PUBLIC, "." + requested);
    if (!file.startsWith(PUBLIC + path.sep) && file !== path.join(PUBLIC,"index.html")) return json(res,403,{error:"Forbidden"});
    fs.readFile(file,(err,data)=>{
      if(err) return json(res,404,{error:"Not found"});
      const ext=path.extname(file), types={".html":"text/html; charset=utf-8",".css":"text/css; charset=utf-8",".js":"text/javascript; charset=utf-8"};
      res.writeHead(200,{"content-type":types[ext]||"application/octet-stream","cache-control":"no-store","x-content-type-options":"nosniff","referrer-policy":"same-origin","x-frame-options":"DENY"});
      res.end(data);
    }); return;
  }
  json(res,404,{error:"Not found"});
});
server.listen(PORT,HOST,()=>{console.log(`Cyber War Room listening on ${HOST}:${PORT}`);log("success","Public website online; admin controls protected.");});
